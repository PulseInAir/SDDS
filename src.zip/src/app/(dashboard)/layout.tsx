import { redirect } from 'next/navigation';
import { createClient } from '@/utils/supabase/server';
import Link from 'next/link';
import { LayoutDashboard, Users, Clock, FileText, Settings, LogOut, Shield, Database, IndianRupee } from 'lucide-react';
import { logout } from '@/app/login/actions';
import { PrivacyProvider } from '@/context/PrivacyContext';
import Header from '@/components/Header';

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
}

function NavItem({ href, icon, label }: NavItemProps) {
  return (
    <Link
      href={href}
      className="flex items-center space-x-3 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/60 transition-all font-medium text-sm group"
    >
      <span className="text-slate-500 group-hover:text-blue-400 transition-colors">{icon}</span>
      <span>{label}</span>
    </Link>
  );
}

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  return (
    <PrivacyProvider>
      <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900/60 border-r border-slate-800/80 flex flex-col justify-between shrink-0 select-none">
          <div>
            {/* Logo */}
            <div className="h-16 flex items-center px-6 border-b border-slate-800/50">
              <Link href="/" className="flex items-center space-x-3">
                <div className="h-9 w-9 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20 ring-1 ring-white/10 shrink-0">
                  <span className="text-white font-black text-sm tracking-tighter">SD</span>
                </div>
                <span className="font-bold text-lg text-white tracking-tight leading-none">SDDS Portal</span>
              </Link>
            </div>

            {/* Navigation Links */}
            <nav className="p-4 space-y-1">
              <NavItem href="/" icon={<LayoutDashboard className="h-4 w-4" />} label="Dashboard" />
              <NavItem href="/clients" icon={<Users className="h-4 w-4" />} label="Clients" />
              <NavItem href="/queue" icon={<Clock className="h-4 w-4" />} label="Filing Queue" />
              <NavItem href="/invoices" icon={<FileText className="h-4 w-4" />} label="Invoices" />
              <NavItem href="/revenue" icon={<IndianRupee className="h-4 w-4" />} label="Revenue / Collections" />
              <NavItem href="/data" icon={<Database className="h-4 w-4" />} label="Data Manager" />
              <NavItem href="/settings" icon={<Settings className="h-4 w-4" />} label="Settings" />
            </nav>
          </div>

          {/* Footer info & Logout */}
          <div className="p-4 border-t border-slate-800/50 space-y-4">
            <div className="flex items-center space-x-3 px-2">
              <div className="h-8 w-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 text-slate-400">
                <Shield className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-300 truncate">Admin User</p>
                <p className="text-[10px] text-slate-500 truncate">{user.email}</p>
              </div>
            </div>

            <form action={logout}>
              <button
                type="submit"
                className="w-full flex items-center space-x-3 px-4 py-2.5 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-950/20 transition-all font-medium text-sm cursor-pointer border-none bg-transparent text-left"
              >
                <LogOut className="h-4 w-4" />
                <span>Sign Out</span>
              </button>
            </form>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 bg-slate-950 overflow-y-auto relative flex flex-col">
          {/* Header */}
          <Header />
          {/* Background glow decoration */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="flex-1 p-8 relative z-10">
            {children}
          </div>
        </main>
      </div>
    </PrivacyProvider>
  );
}
